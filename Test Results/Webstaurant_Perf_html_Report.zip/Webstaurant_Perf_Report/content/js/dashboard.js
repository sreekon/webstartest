/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.7171052631578947, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "product_415C80BAJADA/66009"], "isController": false}, {"data": [0.5, 500, 1500, "webstaurantstore.com_S&D_Outlet_page"], "isController": false}, {"data": [0.875, 500, 1500, "product_372G60436RRN/66021"], "isController": false}, {"data": [0.8333333333333334, 500, 1500, "product_178CBE72HC/66017"], "isController": false}, {"data": [1.0, 500, 1500, "product_499UDF0140AA/66025"], "isController": false}, {"data": [0.75, 500, 1500, "product_185B48GSY1BH/66027"], "isController": false}, {"data": [0.875, 500, 1500, "product_178SS1RHC/66013"], "isController": false}, {"data": [1.0, 500, 1500, "product_178SSUC72RHC/66029"], "isController": false}, {"data": [1.0, 500, 1500, "product_178A49FHC/66037"], "isController": false}, {"data": [1.0, 500, 1500, "product_351GMCPG24NL/66035"], "isController": false}, {"data": [1.0, 500, 1500, "product_499UFP0350AA/66023"], "isController": false}, {"data": [0.875, 500, 1500, "product_178SSUD2R/66015"], "isController": false}, {"data": [1.0, 500, 1500, "product_560MSC66AA/66011"], "isController": false}, {"data": [1.0, 500, 1500, "product_522ETSG2472/66039"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 76, 0, 0.0, 622.6052631578945, 234, 1462, 724.0, 906.8, 1005.0999999999993, 1462.0, 0.08484548075012337, 78.83141843153639, 0.041662855248586095], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["product_415C80BAJADA/66009", 3, 0, 0.0, 360.6666666666667, 338, 383, 361.0, 383.0, 383.0, 383.0, 0.0054755616557368375, 1.4087932130185128, 0.002743128056047849], "isController": false}, {"data": ["webstaurantstore.com_S&D_Outlet_page", 38, 0, 0.0, 859.736842105263, 720, 1462, 840.0, 1001.4000000000001, 1122.849999999999, 1462.0, 0.04356629069722116, 67.51535984932082, 0.021017331644948487], "isController": false}, {"data": ["product_372G60436RRN/66021", 4, 0, 0.0, 428.75, 343, 632, 370.0, 632.0, 632.0, 632.0, 0.010399550739408058, 3.012058746249662, 0.0052099311809729815], "isController": false}, {"data": ["product_178CBE72HC/66017", 3, 0, 0.0, 436.0, 366, 527, 415.0, 527.0, 527.0, 527.0, 0.005205016942330147, 1.5378588533868178, 0.0025974254468073294], "isController": false}, {"data": ["product_499UDF0140AA/66025", 1, 0, 0.0, 380.0, 380, 380, 380.0, 380.0, 380.0, 380.0, 2.631578947368421, 981.6663240131579, 1.318359375], "isController": false}, {"data": ["product_185B48GSY1BH/66027", 2, 0, 0.0, 500.5, 443, 558, 500.5, 558.0, 558.0, 558.0, 0.002974229786019038, 1.1785196733217538, 0.0014900194142849282], "isController": false}, {"data": ["product_178SS1RHC/66013", 4, 0, 0.0, 481.5, 357, 776, 396.5, 776.0, 776.0, 776.0, 0.00867942542203706, 3.300004000672655, 0.004322760708241114], "isController": false}, {"data": ["product_178SSUC72RHC/66029", 2, 0, 0.0, 322.5, 319, 326, 322.5, 326.0, 326.0, 326.0, 0.0037855844942459114, 1.1725866455225997, 0.0018964891069806176], "isController": false}, {"data": ["product_178A49FHC/66037", 2, 0, 0.0, 466.5, 450, 483, 466.5, 483.0, 483.0, 483.0, 0.007435331206828608, 3.0673246295810936, 0.003703143472150967], "isController": false}, {"data": ["product_351GMCPG24NL/66035", 2, 0, 0.0, 373.0, 350, 396, 373.0, 396.0, 396.0, 396.0, 0.0037850400078728833, 1.60458528322035, 0.00189621633206913], "isController": false}, {"data": ["product_499UFP0350AA/66023", 3, 0, 0.0, 312.3333333333333, 245, 427, 265.0, 427.0, 427.0, 427.0, 0.004165127883309777, 0.955365361546984, 0.0020866314493534336], "isController": false}, {"data": ["product_178SSUD2R/66015", 4, 0, 0.0, 382.0, 320, 510, 349.0, 510.0, 510.0, 510.0, 0.0050199291186008455, 1.53298904267128, 0.0025001600102406555], "isController": false}, {"data": ["product_560MSC66AA/66011", 7, 0, 0.0, 301.1428571428571, 234, 413, 281.0, 413.0, 413.0, 413.0, 0.009111617312072894, 1.9650967092417833, 0.0045469105922551255], "isController": false}, {"data": ["product_522ETSG2472/66039", 1, 0, 0.0, 339.0, 339, 339, 339.0, 339.0, 339.0, 339.0, 2.949852507374631, 1501.0543418141592, 1.4749262536873156], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 76, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
